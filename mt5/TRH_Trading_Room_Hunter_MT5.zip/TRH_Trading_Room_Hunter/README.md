# TRH for MetaTrader 5 — Modes A + B (BTB removed)

| File | Role |
|------|------|
| `TRH_Trading_Room_Hunter.mq5` | **Indicator** v2.30 |
| `TRH_AutoTrade.mq5` | **EA** v3.35 |
| `TRH_Engine.mqh` | Shared Engine v229 |

| Mode | Chart name | Live? |
|------|------------|--------|
| **A** | `A · SWEEP` | **Yes** — main classic room |
| **B** | `B · FVG` | **Yes** — sweep + disp + FVG |
| **C** | `C · BTB` | **Removed** from live model |

**Default Detection Mode = `A + B` (Both)** on Indicator and AutoTrade.

## Why Pine found a SWEEP MT5 missed (v228)

Pine `ta.atr(14)` is **Wilder RMA**. Old MT5 used SMA of the last 14 TRs — after a big selloff SMA ATR spikes and `minRoom` fails, so Mode A never confirms. Engine now matches Pine ATR.


Priority when both fire: **A > B**.

## Install

1. Unzip `TRH_Trading_Room_Hunter_MT5.zip`
2. `Indicators/TRH_Trading_Room_Hunter/` ← Engine + Indicator  
3. `Experts/TRH_Trading_Room_Hunter/` ← Engine + EA  
4. Compile both `.mq5` · re-attach  
5. Detection Mode = **A + B (Both)** · AutoTrade ON · Algo Trading ON  

## Live position sync (v2.26+)

Same-account multi-PC: panel shows `LIVE LONG/SHORT` from the open broker position.

## Mode B TV-efficient geometry (v229 / EA v3.35)

TradingView Mode B was producing better Entry/SL/TP than MT5 (higher short entry, SL that survived the stop-hunt, deeper 2.4R TP). Engine now matches that model:

| Level | Old MT5 | New (TV-efficient) |
|-------|---------|---------------------|
| **ENTRY** | FVG mid (0.50) | Bias **0.62** toward proximal |
| **SL** | sweep ± 0.22 ATR | Beyond max(sweep, FVG outer) ± **0.47 ATR**, floor **1.0×ATR** risk |
| **TP** | entry ± risk×2.4 | Same RR, deeper because risk is healthier |

Inputs: `InpFvgEntryBias`, `InpFvgSlExtraAtr`, `InpFvgMinRiskAtr` (Indicator + EA).

## Smart EA fill (v3.35)

- **Far from ENTRY** → **market open immediately** (live SL/TP geometry)
- **Near ENTRY** → pending **Stop/Limit @ ENTRY**
- **Session filter OFF** by default (Asian dumps trade)
- **Adopt age 20 bars** (was 8 — gold was aging out)
- Auto-pad SL vs live bid/ask · retry filling modes (IOC/FOK/RETURN)
- Chart Comment shows block reason (`Algo Trading OFF`, spread, etc.)
- Break-even still **OFF** by default

## Break-even (v3.32 — OFF by default)

**Default = OFF.** SL stays at the setup SL until TP or original SL. No “risk-free”.

That early BE @ ~0.5R was moving SL to entry and stopping trades that dip back then run to TP (exactly what you saw on GOLD).

Optional styles if you turn it on later: `EARLY` / `SMART` / `STEP`.  
Input name is `InpSLProtectStyle` (not the old checkbox) so MT5 does not remount saved “true” as EARLY.

## Links

- Zip: https://github.com/radiarkazemi/forge-charts/raw/cursor/trh-mt5-abc-992e/mt5/TRH_Trading_Room_Hunter_MT5.zip
- Pine: https://raw.githubusercontent.com/radiarkazemi/forge-charts/cursor/trh-mt5-abc-992e/indicators/TRH_Trading_Room_Hunter.pine
- EA: https://raw.githubusercontent.com/radiarkazemi/forge-charts/cursor/trh-mt5-abc-992e/mt5/TRH_Trading_Room_Hunter/TRH_AutoTrade.mq5
- Indicator: https://raw.githubusercontent.com/radiarkazemi/forge-charts/cursor/trh-mt5-abc-992e/mt5/TRH_Trading_Room_Hunter/TRH_Trading_Room_Hunter.mq5
